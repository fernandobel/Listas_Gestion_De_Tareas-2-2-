/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listas_gestion_de_tareas;

/**
 *
 * @author
 */

public class Tarea {
    private int id;
    private String titulo;
    private String descripcion;
    private String fechaLimite;
    private String estado;
    private Lista<Usuario> usuariosAsignado;

    public Tarea() {
        this.id = 0;
        this.titulo = null;
        this.descripcion = null;
        this.fechaLimite = null;
        this.estado = null;
        this.usuariosAsignado = new Lista();
    }  
    
    public Tarea(int id, String titulo, String descripcion, String fechaLimite) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaLimite = fechaLimite;
        this.estado = Estado.getPENDIENTE();
        this.usuariosAsignado = new Lista();
    }
    
    public Tarea(int id, String titulo, String descripcion, String fechaLimite, String estado) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaLimite = fechaLimite;
        this.estado = estado;
        this.usuariosAsignado = new Lista();
    }  
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(String fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    public String getEstado() {
        return estado;
    }
    
    public void setEstado(int estado) {
        this.estado = Estado.getEstado(estado);
    }

    public String getUsuariosAsignado() {
        String out = "";
        Usuario usuarioTemp = new Usuario();
        for (int i=0; i < usuariosAsignado.getTamanio(); i++) {
            usuarioTemp = usuariosAsignado.get(i);
            out += usuarioTemp.getId();
            if (i <= usuariosAsignado.getTamanio()-1) {
                out += "~";
            }
        }
        if ("".equals(out)) {
            return "SIN ASIGNAR";
        }
        return out;
    }

    public void setUsuariosAsignado(Lista<Usuario> usuariosAsignado) {
        this.usuariosAsignado = usuariosAsignado;
    }

    public boolean asignarUsuario(Usuario usuario) {
        if (this.usuariosAsignado.agregar(usuario)) {
            this.estado = Estado.getASIGNADA();
            return true;
        } else {  
            return false;
        }   
    }
    
    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Tarea: " + titulo + ", Descripción: " + descripcion + ", Fecha Límite: " + fechaLimite + ", Estado: " + estado;
    }
}