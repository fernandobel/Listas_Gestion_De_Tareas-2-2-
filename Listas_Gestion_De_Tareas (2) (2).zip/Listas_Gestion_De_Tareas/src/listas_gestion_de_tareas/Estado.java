/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package listas_gestion_de_tareas;

/**
 *
 * @author 
 */
public enum Estado {
    PENDIENTE, ASIGNADA, ENCURSO, COMPLETADA;

    public static String getPENDIENTE() {
        return PENDIENTE.toString();
    }

    public static String getASIGNADA() {
        return ASIGNADA.toString();
    }

    public static String getENCURSO() {
        return ENCURSO.toString();
    }

    public static String getCOMPLETADA() {
        return COMPLETADA.toString();
    }
    
     public static String getEstado(int n) {
        switch(n) {
            case 1:
                return getPENDIENTE();
            case 2:
                return getASIGNADA();
            case 3:
                return getENCURSO();
            case 4:
                return getCOMPLETADA();
            default:
                return null;
        }
    }
}
