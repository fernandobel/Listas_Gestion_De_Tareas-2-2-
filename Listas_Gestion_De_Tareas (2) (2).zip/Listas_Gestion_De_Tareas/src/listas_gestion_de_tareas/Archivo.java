/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listas_gestion_de_tareas;

/**
 *
 * @author 
 */
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;

public class Archivo {
    
    static String rutaActual = Paths.get("").toAbsolutePath().toString();
    static String usuariosArchivo = rutaActual + "\\src\\listas_gestion_de_tareas\\usuarios.txt"; 
    static String tareasArchivo = rutaActual + "\\src\\listas_gestion_de_tareas\\tareas.txt"; 


    public static Lista<Usuario> cargarUsuarios() {
        Lista<Usuario> usuarios = new Lista();
        Usuario usuarioTemp = new Usuario();
        try {
            Scanner leer = new Scanner(new FileReader(usuariosArchivo));
            String numCedula, nombre, apellido, nombreDeUsuario, contrasenya;
            int id;
            boolean isAdmin;
            while (leer.hasNextLine()) {
                String line = leer.nextLine();
                String[] separado = line.split(";");
                id = Integer.parseInt(separado[0]);
                numCedula = separado[1];
                nombre = separado[2];
                apellido = separado[3];
                nombreDeUsuario = separado[4];
                contrasenya = separado[5];
                isAdmin = Boolean.parseBoolean(separado[6]);
                usuarioTemp = new Usuario(id, numCedula, nombre, apellido, nombreDeUsuario, contrasenya, isAdmin);
                usuarios.agregar(usuarioTemp);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"usuarios.txt\" no encontrado.");
        } catch (IOException ioe) {
             System.out.println("El archivo \"usuarios.txt\" no se puede leer.");
        }
        return usuarios;
    }
    
    public static void registrarUsuarios(Lista<Usuario> usuarios) {
        FileWriter file = null;
        BufferedWriter bw = null;
        try {
            file = new FileWriter(usuariosArchivo, false);
            bw = new BufferedWriter(file);
            Usuario usuarioTemp = new Usuario();
            for (int i = 0; i < usuarios.getTamanio(); i++) {
                usuarioTemp = usuarios.get(i);
                bw.write(usuarioTemp.getId() + ";" + usuarioTemp.getNumCedula() + ";" + usuarioTemp.getNombre() + ";" + usuarioTemp.getApellido() + ";" + usuarioTemp.getNombreDeUsuario()  + ";" + usuarioTemp.getContrasenya() + ";" + usuarioTemp.isAdmin());
                bw.newLine();
            }            
            bw.flush();
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"usuarios.txt\" no encontrado.");
        } catch (IOException ioe) {
            System.out.println("El archivo \"usuarios.txt\" no se puede leer.");
        } finally {
            try {
                if(bw != null) { 
                    bw.close();
                }
                if(file != null) { 
                    file.close();
                } 
            } catch (IOException ioe) { }
        }
    }
    
    public static Lista<Tarea> cargarTareas() {
        Lista<Tarea> tareas = new Lista();
        Tarea tareaTemp = new Tarea();
        try {
            Scanner leer = new Scanner(new FileReader(tareasArchivo));
            String titulo, descripcion, fechaLimite, estado, asignados;
            int id;
            Lista<Usuario> usuarios = cargarUsuarios();
            while (leer.hasNextLine()) {
                String line = leer.nextLine();
                String[] separado = line.split(";");
                id = Integer.parseInt(separado[0]);
                titulo = separado[1];
                descripcion = separado[2];
                fechaLimite = separado[3];
                estado = separado[4];
                asignados = separado[5];
                tareaTemp = new Tarea(id, titulo, descripcion, fechaLimite, estado);
                
                if (!"SIN ASIGNAR".equals(asignados)) {
                    // Asignar usuarios a una tarea
                    String[] usuariosAsignados = asignados.split("~");
                    for (int i = 0; i < usuariosAsignados.length; i++) {
                        Usuario usuarioTemp = new Usuario();
                        for (int j=0; i < usuarios.getTamanio(); i++) {
                            usuarioTemp = usuarios.get(j);
                            if (usuarioTemp.getNombreDeUsuario().equals(usuariosAsignados[j])) {
                                tareaTemp.asignarUsuario(usuarioTemp);
                            }
                        }
                    }
                }
                tareas.agregar(tareaTemp);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"tareas.txt\" no encontrado.");
        } catch (IOException ioe) {
             System.out.println("El archivo \"tareas.txt\" no se puede leer.");
        }
        return tareas;
    }
    
    public static void registrarTareas(Lista<Tarea> tareas) {
        FileWriter file = null;
        BufferedWriter bw = null;
        try {
            file = new FileWriter(tareasArchivo, false);
            bw = new BufferedWriter(file);
            Tarea tareaTemp = new Tarea();
            for (int i = 0; i < tareas.getTamanio(); i++) {
                tareaTemp = tareas.get(i);
                bw.write(tareaTemp.getId() + ";" + tareaTemp.getTitulo() + ";" + tareaTemp.getDescripcion() + ";" + tareaTemp.getFechaLimite() + ";" + tareaTemp.getEstado() + ";" + tareaTemp.getUsuariosAsignado() );
                bw.newLine();
            }            
            bw.flush();
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"tareas.txt\" no encontrado.");
        } catch (IOException ioe) {
            System.out.println("El archivo \"tareas.txt\" no se puede leer.");
        } finally {
            try {
                if(bw != null) { 
                    bw.close();
                }
                if(file != null) { 
                    file.close();
                } 
            } catch (IOException ioe) { }
        }
    }
}