/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listas_gestion_de_tareas;

/**
 *
 * @author
 * @param <T>
 */
public class Nodo<T> {

    private T info;
    private Nodo sig = null;

    public Nodo(T info, Nodo sig) {
        this.info = info;
        this.sig = sig;
    }
    
    public Nodo(T info) {
        this.info = info;
        this.sig = null;
    }
    
    public T getInfo() {
        return info;
    }

    public void setInfo(T info) {
        this.info = info;
    }

    public Nodo getSig() {
        return sig;
    }

    public void setSig(Nodo sig) {
        this.sig = sig;
    }
}
