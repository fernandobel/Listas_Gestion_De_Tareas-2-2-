/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listas_gestion_de_tareas;

import java.util.Scanner;

/**
 *
 * @author 
 */
public class Listas_Gestion_De_Tareas {
    static Scanner sc = new Scanner(System.in);
    private static Lista<Usuario> usuarios = Archivo.cargarUsuarios();
    private static Lista<Tarea> tareas = Archivo.cargarTareas();
    private static Usuario usuarioActual = new Usuario();
    
    static Lista<Tarea> devolverListado(String estado) {
        Lista<Tarea> listaTemp = new Lista();
        Tarea tareaTemp = new Tarea();
        for (int i=0; i < tareas.getTamanio(); i++) {
            tareaTemp = tareas.get(i);
            if (estado.equals(tareaTemp.getEstado())) {
                listaTemp.agregar(tareaTemp);
            }
        }
        return listaTemp;
    }
    
    static void crearTarea() {
        sc.nextLine(); 
        System.out.println("Formulario de Creación de Tarea \n");
        System.out.print("Título de la tarea: ");
        String titulo = sc.nextLine();
        System.out.print("Breve descripción: ");
        String descripcion = sc.nextLine();
        System.out.print("Fecha límite de la tarea (dd/mm/aaaa): ");
        String fechaLimite = sc.nextLine();

        int id = tareas.getTamanio() + 1;
        Tarea nuevaTarea = new Tarea(id, titulo, descripcion, fechaLimite);
        tareas.agregar(nuevaTarea);
        System.out.println("¡Tarea creada exitosamente!");
    }
    
    static void organizarTareas() {
        System.out.println("\nTareas:");
        System.out.println(tareas.listar());
    }
    
    static void mostrarListado(int op) {
        switch (op) {
            case 1:
                System.out.println("\nTareas Pendientes:");
                System.out.println(devolverListado("PENDIENTE").listar());
                break;
            case 2:
                System.out.println("\nTareas Asignadas:");
                System.out.println(devolverListado("ASIGNADA").listar());
                break;
            case 3:
                System.out.println("\nTareas en Curso:");
                System.out.println(devolverListado("ENCURSO").listar());
                break;
            case 4:
                System.out.println("\nTareas Completadas:");
                System.out.println(devolverListado("COMPLETADA").listar());
                break;
            default:
                System.out.println("Opción no válida, por favor intente de nuevo.");
        }
    }
    
    static Lista getListado(int op) {
        switch (op) {
            case 1:
                return devolverListado("PENDIENTE");
            case 2:
                return devolverListado("ASIGNADA");
            case 3:
                return devolverListado("ENCURSO");
            case 4:
                return devolverListado("COMPLETADA");
            default:
                return null;
        }
    }

    static void cambiarEstadoTarea() {
        sc.nextLine();
        System.out.println("Formulario de Cambio de Estado \n");
        System.out.println("Seleccione el estado a cambiar: ");
        System.out.println("1. Tareas Pendientes");
        System.out.println("2. Tareas Asignadas");
        System.out.println("3. Tareas En Curso");
        System.out.println("4. Tareas Completadas");
        int op = sc.nextInt();
        mostrarListado(op);
        Lista<Tarea> temp = getListado(op);
        System.out.print("Número de la tarea: ");
        op = sc.nextInt();
        Tarea tarea = temp.get(op);

        if (tarea != null) {
            System.out.println("Tarea encontrada: " + tarea.getTitulo());
            System.out.println("Ingrese el nuevo estado: ");
            System.out.println("1. Pendiente");
            System.out.println("2. Asignada");
            System.out.println("3. En Curso");
            System.out.println("4. Completada");
            int nuevoEstado = sc.nextInt();
            tarea.setEstado(nuevoEstado);
            
            System.out.println("Estado de la tarea actualizado.");
        } else {
            System.out.println("Tarea no encontrada.");
        }
    }
        
    static void asignarTarea() {
        sc.nextLine();
        Lista<Tarea> listaTemp = devolverListado("PENDIENTE");
        if (!listaTemp.estaVacio()) {
            System.out.println("Formulario de Asignación de Tarea \n");
            System.out.println("Seleccione una tarea pendiente: ");
            System.out.println(listaTemp.listar());
            System.out.print("Número de la tarea: ");
            int op = sc.nextInt();
            Tarea tareaTemp = listaTemp.get(op);

            System.out.println("Seleccione un usuario: ");
            System.out.print(usuarios.listar());
            System.out.print("Número de usuario: ");
            op = sc.nextInt();
            Usuario usuarioTemp = usuarios.get(op);

            if (tareaTemp.asignarUsuario(usuarioTemp)) {
                System.out.println("Tarea Asignada.");
            } else {
                System.out.println("Error.");
            }
        } else {
            System.out.println("Debe tener tareas pendientes");
        }
    }
    
    static void usuariosAsignados() {
        sc.nextLine();
        Lista<Tarea> listaTemp = devolverListado("ASIGNADA");
        System.out.println("Formulario para mostrar usuarios asignados\n");
        System.out.println("Seleccione una tarea asignada: ");
        System.out.println(listaTemp.listar());
        System.out.print("Número de la tarea: ");
        int op = sc.nextInt();
        Tarea tareaTemp = listaTemp.get(op);
        tareaTemp.getUsuariosAsignado();
    }
    
    static void mostrarMenuUsuario() {
        while (true) {
            System.out.println("\nMenú de Tareas: \n");
            System.out.println("1. Crear nueva tarea");
            System.out.println("2. Organizar tareas");
            System.out.println("3. Asignar tarea");
            System.out.println("4. Actualizar estado de tarea");
            System.out.println("5. Usuarios Asiganados");
            if (usuarioActual.isAdmin()) {
                System.out.println("6. Gestionar Usuarios");
            }
            System.out.println("0. Cerrar sesión");
            int opcion = sc.nextInt();
            
            switch (opcion) {
                case 0:
                    System.out.println("Cerrando sesión...");
                    usuarioActual = null;
                    return; 
                case 1:
                    crearTarea();
                    break;
                case 2:
                    organizarTareas();
                    break;
                case 3:
                    asignarTarea();
                    break;
                case 4:
                    cambiarEstadoTarea();
                    break;
                case 5:
                    usuariosAsignados();
                    break;
                case 6:
                    menuGestionUsuarios();
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        }
    }
    
    private static void iniciarSesion() {
        sc.nextLine();  
        System.out.println("Formulario de Inicio de Sección \n");
        System.out.print("Nombre de Usuario: ");
        String nombreDeUsuario = sc.nextLine();
        System.out.print("Contraseña: ");
        String contrasenya = sc.nextLine();
        
        Usuario usuarioTemp;
        for (int i=0; i < usuarios.getTamanio(); i++) {
            usuarioTemp = usuarios.get(i);
            if (usuarioTemp.getNombreDeUsuario().equals(nombreDeUsuario) && usuarioTemp.getContrasenya().equals(contrasenya)) {
                usuarioActual = usuarioTemp;
                System.out.println("\n Bienvenido, " + usuarioActual.toString());
                break;
            }
        }
        if (usuarioActual != null) {
            mostrarMenuUsuario();
        } else {
            System.out.println("Nombre de usuario o contraseña incorrectos. \n");   
        }
    }

    private static void registrarUsuario() {
        sc.nextLine();  
        System.out.println("Formulario de Registro \n");
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Apellido: ");
        String apellido = sc.nextLine();
        System.out.print("Número de Cédula: ");
        String cedula = sc.nextLine();
        System.out.print("Nombre de Usuario: ");
        String nombreDeUsuario = sc.nextLine();
        System.out.print("Contraseña: ");
        String contrasenya = sc.nextLine();

        int id = usuarios.getTamanio() + 1;
        Usuario nuevoUsuario = new Usuario(id, cedula, nombre, apellido, nombreDeUsuario, contrasenya, false);
        usuarios.agregar(nuevoUsuario);
        System.out.println("¡Registro exitoso!");
        System.out.println("Ahora puede iniciar sesión. \n");
    }
    
    private static void eliminarUsuario() {
        sc.nextLine();  
        System.out.println("Formulario de Eliminación \n");
        System.out.println("Seleccione un usuario: ");
        System.out.print(usuarios.listar());
        System.out.print("Número de usuario: ");
        int op = sc.nextInt();
        Usuario usuarioTemp = usuarios.get(op);
        
        if (usuarios.eliminar(usuarioTemp)) {
            System.out.println("Usuario eliminado.");
        } else {
            System.out.println("Error.");
        }
    }
    
    private static void menuGestionUsuarios() {
        sc.nextLine();  
        System.out.println("\nMenu de Gestion \n");
        System.out.println("1. Crear Usuario");
        System.out.println("2. Eliminar Usuario");
        int op = sc.nextInt();
        switch (op) {
            case 1:
                registrarUsuario();
                break;
            case 2:
                eliminarUsuario();
                break;
            default:
                System.out.println("Opción no válida, por favor intente de nuevo.");
            }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        usuarioActual = null;
        boolean salir = false;
        do {
            System.out.println("Bienvenid@ al Sistema de Gestión de Tareas \n");
            System.out.println("1. Iniciar Sección");
            System.out.println("2. Salir");
            System.out.println("");
            int opcion = sc.nextInt();
            switch (opcion) {
                case 1:
                    iniciarSesion();
                    break;
                case 2:
                    Archivo.registrarTareas(tareas);
                    Archivo.registrarUsuarios(usuarios);   
                    System.out.println("Gracias por utilizar nuestro Sistema!");
                    salir = true;
                    break; 
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
        } while (!salir);   
    }
}
