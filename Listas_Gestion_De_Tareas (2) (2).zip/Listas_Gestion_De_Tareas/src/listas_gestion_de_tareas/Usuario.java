/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listas_gestion_de_tareas;

/**
 *
 * @author 
 */
public class Usuario {
    private int id;
    private String numCedula;
    private String nombre;
    private String apellido;
    private String nombreDeUsuario;
    private String contrasenya;
    private boolean admin;

    public Usuario() {
        this.id = 0;
        this.numCedula = null;
        this.nombre = null;
        this.apellido = null;
        this.nombreDeUsuario = null;
        this.contrasenya = null;
        this.admin = false;
    }
    
    public Usuario(int id, String numCedula, String nombre, String apellido, String nombreDeUsuario, String contrasenya, boolean isAdmin) {
        this.id = id;
        this.numCedula = numCedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.nombreDeUsuario = nombreDeUsuario;
        this.contrasenya = contrasenya;
        this.admin = isAdmin;
    }
    
    public String getNombreDeUsuario() {
        return nombreDeUsuario;
    }

    public void setNombreDeUsuario(String nombreDeUsuario) {
        this.nombreDeUsuario = nombreDeUsuario;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }
    
    public String getNumCedula() {
        return numCedula;
    }

    public void setNumCedula(String numCedula) {
        this.numCedula = numCedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean esAdmin) {
        this.admin = esAdmin;
    }
    
    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Nombre: " + this.nombre + " " + this.apellido;
    }
}
